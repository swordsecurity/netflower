from distutils.core import setup

setup(
    name='Netflower',
    version='0.1dev',
    packages=['netflower',],
    license='MIT license',
    long_description=open('README.txt').read(),
)
