Analyse a network interface and show live bandwidth usage for every IP
